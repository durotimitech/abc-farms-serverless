"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DB_TABLE_NAMES = exports.docClient = void 0;
const aws_sdk_1 = require("aws-sdk");
exports.docClient = new aws_sdk_1.DynamoDB.DocumentClient({
    region: "us-east-1",
    maxRetries: 3,
    httpOptions: {
        timeout: 5000,
    },
});
exports.DB_TABLE_NAMES = {
    PRODUCTS: process.env.PRODUCTS_TABLE_NAME,
};
//# sourceMappingURL=dbHelper.js.map