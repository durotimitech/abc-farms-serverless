"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.docClient = void 0;
const aws_sdk_1 = require("aws-sdk");
exports.docClient = new aws_sdk_1.DynamoDB.DocumentClient({
    region: "us-east-1",
    maxRetries: 3,
    httpOptions: {
        timeout: 5000,
    },
});
//# sourceMappingURL=dbHelper.js.map