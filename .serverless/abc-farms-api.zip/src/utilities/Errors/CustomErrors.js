"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BadRequestError = void 0;
const logger_1 = __importDefault(require("../logger"));
const BaseError_1 = __importDefault(require("./BaseError"));
class BadRequestError extends BaseError_1.default {
    constructor(message, data = null) {
        super(message, 400, data);
        logger_1.default.error(message);
    }
}
exports.BadRequestError = BadRequestError;
// export class UnauthorizedError extends CustomError {
//   constructor(message: string, data: any = null) {
//     super(message, 401, data);
// logger.error(message);
//   }
// }
// export class ForbiddenError extends CustomError {
//   constructor(message: string, data: any = null) {
//     super(message, 403, data);
// logger.error(message);
//   }
// }
// export class NotFoundError extends CustomError {
//   constructor(message: string, data: any = null) {
//     super(message, 404, data);
// logger.error(message);
//   }
// }
// export class ConflictError extends CustomError {
//   constructor(message: string, data: any = null) {
//     super(message, 409, data);
// logger.error(message);
//   }
// }
// export class InternalServerError extends CustomError {
//   constructor(message: string, data: any = null) {
//     super(message, 500, data);
// logger.error(message);
//   }
// }
//# sourceMappingURL=CustomErrors.js.map