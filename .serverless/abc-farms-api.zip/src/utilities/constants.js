"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EVENT_BUS_NAME = exports.DB_TABLE_NAMES = void 0;
exports.DB_TABLE_NAMES = {
    PRODUCTS: process.env.PRODUCTS_TABLE_NAME,
    ORDERS: process.env.ORDERS_TABLE_NAME,
};
exports.EVENT_BUS_NAME = process.env.EVENT_BUS_NAME;
//# sourceMappingURL=constants.js.map