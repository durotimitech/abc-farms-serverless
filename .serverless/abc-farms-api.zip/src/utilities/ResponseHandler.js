"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseHandler = exports.StatusCodes = void 0;
var StatusCodes;
(function (StatusCodes) {
    StatusCodes[StatusCodes["OK"] = 200] = "OK";
    StatusCodes[StatusCodes["CREATED"] = 201] = "CREATED";
    StatusCodes[StatusCodes["INTERNAL_SERVER_ERROR"] = 500] = "INTERNAL_SERVER_ERROR";
    StatusCodes[StatusCodes["BAD_REQUEST"] = 400] = "BAD_REQUEST";
})(StatusCodes = exports.StatusCodes || (exports.StatusCodes = {}));
const ResponseHandler = ({ statusCode, body }) => {
    return {
        statusCode,
        body: JSON.stringify(body, null, 2),
    };
};
exports.ResponseHandler = ResponseHandler;
//# sourceMappingURL=ResponseHandler.js.map