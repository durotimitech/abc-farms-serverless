"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dbHelper_1 = require("../utilities/dbHelper");
class ProductsService {
    static async getProduct(id) {
        try {
            const params = {
                TableName: this.TABLE_NAME,
                Key: { id },
            };
            const product = await dbHelper_1.docClient.get(params).promise();
            return product.Item;
        }
        catch (e) {
            return e.message;
        }
    }
}
ProductsService.TABLE_NAME = dbHelper_1.DB_TABLE_NAMES.PRODUCTS;
exports.default = ProductsService;
//# sourceMappingURL=Products.js.map