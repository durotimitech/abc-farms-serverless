"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const constants_1 = require("../utilities/constants");
const dbHelper_1 = require("../utilities/dbHelper");
class ProductsService {
    static async getProduct(id) {
        let res = {
            success: false,
            data: {},
            errMessage: "",
        };
        try {
            const params = {
                TableName: this.TABLE_NAME,
                Key: { id },
            };
            const product = await dbHelper_1.docClient.get(params).promise();
            if (!product.Item) {
                res.errMessage = `Product with id ${id} not found`;
                return res;
            }
            res.success = true;
            res.data = product.Item;
            return res;
        }
        catch (e) {
            res.errMessage = e.message;
            return res;
        }
    }
}
ProductsService.TABLE_NAME = constants_1.DB_TABLE_NAMES.PRODUCTS;
exports.default = ProductsService;
//# sourceMappingURL=Products.js.map