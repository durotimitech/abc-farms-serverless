"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteProduct = exports.updateProduct = exports.getProducts = exports.addProduct = void 0;
const ResponseHandler_1 = require("./utilities/ResponseHandler");
const products_1 = require("./utilities/validators/products");
const DynamoDB = require("aws-sdk/clients/dynamodb");
const docClient = new DynamoDB.DocumentClient({
    region: "us-east-1",
    maxRetries: 3,
    httpOptions: {
        timeout: 5000,
    },
});
const PRODUCTS_TABLE_NAME = process.env.PRODUCTS_TABLE_NAME;
const addProduct = async (event) => {
    const validate = products_1.addProductSchema.validate(JSON.parse(event.body));
    if (validate.error) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.BAD_REQUEST,
            body: { message: validate.error.details[0].message },
        });
    }
    const { name, price, qty } = validate.value;
    const id = Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    try {
        const params = {
            TableName: PRODUCTS_TABLE_NAME,
            Item: {
                id,
                name,
                price,
                qty,
            },
            ConditionExpression: "attribute_not_exists(id)",
        };
        await docClient.put(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Product added successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.addProduct = addProduct;
const getProducts = async (event) => {
    try {
        const params = {
            TableName: PRODUCTS_TABLE_NAME,
        };
        const products = await docClient.scan(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.OK,
            body: { message: products },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.getProducts = getProducts;
const updateProduct = async (event) => {
    var _a;
    const productId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
    const validate = products_1.addProductSchema.validate(JSON.parse(event.body));
    if (validate.error) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.BAD_REQUEST,
            body: { message: validate.error.details[0].message },
        });
    }
    const { name, price, qty } = validate.value;
    try {
        const params = {
            TableName: PRODUCTS_TABLE_NAME,
            Key: {
                id: productId,
            },
            UpdateExpression: "set #name = :name, #price = :price, #qty = :qty",
            ExpressionAttributeNames: {
                "#name": "name",
                "#price": "price",
                "#qty": "qty",
            },
            ExpressionAttributeValues: {
                ":name": name,
                ":price": price,
                ":qty": qty,
            },
            ConditionExpression: "attribute_exists(id)",
        };
        await docClient.update(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Product edited successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.updateProduct = updateProduct;
const deleteProduct = async (event) => {
    var _a;
    const productId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
    try {
        const params = {
            TableName: PRODUCTS_TABLE_NAME,
            Key: {
                id: productId,
            },
            ConditionExpression: "attribute_exists(id)",
        };
        await docClient.delete(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Product deleted successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.deleteProduct = deleteProduct;
//# sourceMappingURL=products.js.map