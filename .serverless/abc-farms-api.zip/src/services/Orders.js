"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class OrdersService {
    // private static TABLE_NAME = DB_TABLE_NAMES.PRODUCTS as string;
    static async calculateOrderTotal({ qty, price }) {
        const total = qty * price;
        return total;
    }
}
exports.default = OrdersService;
//# sourceMappingURL=Orders.js.map