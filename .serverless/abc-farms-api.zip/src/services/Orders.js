"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const constants_1 = require("../utilities/constants");
const dbHelper_1 = require("../utilities/dbHelper");
class OrdersService {
    static async createOrder({ productId, qty, price }) {
        let res = {
            success: false,
            data: { id: "" },
            errMessage: "",
        };
        const id = Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
        const orderTotal = qty * price;
        try {
            const params = {
                TableName: OrdersService.TABLE_NAME,
                Item: {
                    id,
                    productId,
                    qty,
                    orderTotal,
                },
                ConditionExpression: "attribute_not_exists(id)",
            };
            await dbHelper_1.docClient.put(params).promise();
            res.success = true;
            res.data.id = id;
            return res;
        }
        catch (e) {
            res.errMessage = e.message;
            return res;
        }
    }
}
OrdersService.TABLE_NAME = constants_1.DB_TABLE_NAMES.ORDERS;
exports.default = OrdersService;
//# sourceMappingURL=Orders.js.map