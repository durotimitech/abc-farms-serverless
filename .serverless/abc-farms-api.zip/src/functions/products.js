"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteProduct = exports.updateProduct = exports.getProduct = exports.getProducts = exports.addProduct = void 0;
const products_1 = require("../utilities/validators/products");
const ResponseHandler_1 = require("../utilities/ResponseHandler");
const dbHelper_1 = require("../utilities/dbHelper");
const Products_1 = __importDefault(require("../services/Products"));
const constants_1 = require("../utilities/constants");
const addProduct = async (event) => {
    const validate = products_1.addProductSchema.validate(JSON.parse(event.body));
    if (validate.error) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.BAD_REQUEST,
            body: { message: validate.error.details[0].message },
        });
    }
    const { name, price, qty } = validate.value;
    const id = Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    try {
        const params = {
            TableName: constants_1.DB_TABLE_NAMES.PRODUCTS,
            Item: {
                id,
                name,
                price,
                qty,
            },
            ConditionExpression: "attribute_not_exists(id)",
        };
        await dbHelper_1.docClient.put(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Product added successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.addProduct = addProduct;
const getProducts = async (event) => {
    try {
        const params = {
            TableName: constants_1.DB_TABLE_NAMES.PRODUCTS,
        };
        const products = await dbHelper_1.docClient.scan(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.OK,
            body: { message: products },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.getProducts = getProducts;
const getProduct = async (event) => {
    var _a;
    const id = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
    try {
        const product = await Products_1.default.getProduct(id || "");
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.OK,
            body: { data: product },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { data: JSON.stringify(e) },
        });
    }
};
exports.getProduct = getProduct;
const updateProduct = async (event) => {
    var _a;
    const productId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
    const validate = products_1.addProductSchema.validate(JSON.parse(event.body));
    if (validate.error) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.BAD_REQUEST,
            body: { message: validate.error.details[0].message },
        });
    }
    const { name, price, qty } = validate.value;
    try {
        const params = {
            TableName: constants_1.DB_TABLE_NAMES.PRODUCTS,
            Key: {
                id: productId,
            },
            UpdateExpression: "set #name = :name, #price = :price, #qty = :qty",
            ExpressionAttributeNames: {
                "#name": "name",
                "#price": "price",
                "#qty": "qty",
            },
            ExpressionAttributeValues: {
                ":name": name,
                ":price": price,
                ":qty": qty,
            },
            ConditionExpression: "attribute_exists(id)",
        };
        await dbHelper_1.docClient.update(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Product edited successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.updateProduct = updateProduct;
const deleteProduct = async (event) => {
    var _a;
    const productId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
    try {
        const params = {
            TableName: constants_1.DB_TABLE_NAMES.PRODUCTS,
            Key: {
                id: productId,
            },
            ConditionExpression: "attribute_exists(id)",
        };
        await dbHelper_1.docClient.delete(params).promise();
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Product deleted successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.deleteProduct = deleteProduct;
//# sourceMappingURL=products.js.map