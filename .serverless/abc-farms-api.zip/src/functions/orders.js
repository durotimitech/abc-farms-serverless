"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOrder = void 0;
const orders_1 = require("../utilities/validators/orders");
const ResponseHandler_1 = require("../utilities/ResponseHandler");
const Products_1 = __importDefault(require("../services/Products"));
const Orders_1 = __importDefault(require("../services/Orders"));
const createOrder = async (event) => {
    const validate = orders_1.createOrderSchema.validate(JSON.parse(event.body));
    if (validate.error) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.BAD_REQUEST,
            body: { message: validate.error.details[0].message },
        });
    }
    const { orderItems } = validate.value;
    try {
        await Promise.all(orderItems.map(async ({ productId, qty }) => {
            const product = await Products_1.default.getProduct(productId);
            if (product && product.qty >= qty) {
                const orderTotal = Orders_1.default.calculateOrderTotal({ qty, price: product.price });
                //   const orderId = await placeOrder(item, orderTotal, req, res);
                //   await updateProductQuantity(item, product, res);
                //   sendEmail({
                //     emails: [req.user.email, process.env.EMAIL],
                //     subject: "Your order has been confirmed",
                //     emailType: "order create",
                //     content: {},
                //   });
            }
        }));
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { message: "Order created successfully" },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.INTERNAL_SERVER_ERROR,
            body: { message: JSON.stringify(e) },
        });
    }
};
exports.createOrder = createOrder;
//# sourceMappingURL=orders.js.map