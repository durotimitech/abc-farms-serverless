"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOrder = void 0;
const orders_1 = require("../utilities/validators/orders");
const ResponseHandler_1 = require("../utilities/ResponseHandler");
const Products_1 = __importDefault(require("../services/Products"));
const Orders_1 = __importDefault(require("../services/Orders"));
const aws_sdk_1 = require("aws-sdk");
const constants_1 = require("../utilities/constants");
const logger_1 = __importDefault(require("../utilities/logger"));
const CustomErrors_1 = require("../utilities/Errors/CustomErrors");
const eventBridgeClient = new aws_sdk_1.EventBridge({ region: "us-east-1" });
const createOrder = async (event) => {
    logger_1.default.info("'createOrder': event called");
    try {
        const validate = orders_1.createOrderSchema.validate(JSON.parse(event.body));
        if (validate.error) {
            throw new CustomErrors_1.BadRequestError(validate.error.details[0].message);
        }
        logger_1.default.info("'createOrder': request body validated");
        const { orderItems } = validate.value;
        await Promise.all(orderItems.map(async ({ productId, qty }) => {
            const product = await Products_1.default.getProduct(productId);
            logger_1.default.info(`'createOrder': ${JSON.stringify(product)}`);
            if (!product.success) {
                throw new CustomErrors_1.BadRequestError(product.errMessage);
            }
            logger_1.default.info(`'createOrder': product with id ${productId} found`);
            if (qty > product.data.qty) {
                throw new CustomErrors_1.BadRequestError(`Product with id ${productId} has only ${product.data.qty} items left`);
            }
            logger_1.default.info(`'createOrder': product with id ${productId} has enough items`);
            logger_1.default.info(`'createOrder': creating order for product with id ${productId}`);
            const createOrder = await Orders_1.default.createOrder({
                productId,
                qty,
                price: product.data.price,
            });
            if (!createOrder.success) {
                throw new CustomErrors_1.BadRequestError(createOrder.errMessage);
            }
            logger_1.default.info(`'createOrder': order created for product with id ${productId} and order id ${createOrder.data.id}`);
            logger_1.default.info(`'createOrder': sending event to EventBridge to notify order created`);
            const entry = {
                EventBusName: constants_1.EVENT_BUS_NAME,
                Detail: JSON.stringify({
                    id: createOrder.data.id,
                }),
                Source: "abc-farms-events",
                DetailType: "order-created",
            };
            const eventBridgeParams = { Entries: [entry] };
            await eventBridgeClient.putEvents(eventBridgeParams).promise();
        }));
        return (0, ResponseHandler_1.ResponseHandler)({
            statusCode: ResponseHandler_1.StatusCodes.CREATED,
            body: { data: { message: "Order created successfully" } },
        });
    }
    catch (e) {
        return (0, ResponseHandler_1.ErrorResponseHandler)(e);
    }
};
exports.createOrder = createOrder;
//# sourceMappingURL=orders.js.map